# Trang web mô phỏng hệ thống bán vé máy bay trực tuyến

# Cách cài đặt 
`npm i OnlineFlightManagement --save`