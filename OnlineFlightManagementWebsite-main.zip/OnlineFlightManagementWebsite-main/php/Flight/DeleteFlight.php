<?php require_once("../../class/flight.php");
die($Query = $FlightObject->DeleteFlight($_POST["ID"]));
