<?php require_once("../../class/plane.php");
die($PlaneObject->DeletePlane($_POST["ID"]));
