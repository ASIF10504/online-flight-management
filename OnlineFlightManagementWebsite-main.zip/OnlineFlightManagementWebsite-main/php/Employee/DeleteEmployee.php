<?php require_once("../../class/employee.php");
die($Query = $EmployeeObject->DeleteEmployee($_POST["ID"]));
