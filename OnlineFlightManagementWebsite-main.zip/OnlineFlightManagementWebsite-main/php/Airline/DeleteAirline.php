<?php require_once("../../class/airline.php");
die($AirlineObject->DeleteAirline($_POST["ID"]));
