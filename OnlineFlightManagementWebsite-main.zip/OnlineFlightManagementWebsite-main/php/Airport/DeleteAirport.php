<?php require_once("../../class/airport.php");
die($AirportObject->DeleteAirport($_POST["ID"]));
